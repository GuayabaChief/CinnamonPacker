package com.cinnamon.packer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PackerApplication.class, args);
	}

}
