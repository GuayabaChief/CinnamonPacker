package com.cinnamon.packer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
